export const environment = {
  production: true,
  url: 'http://127.255.255.1'
};
