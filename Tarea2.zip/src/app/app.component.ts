import { Component, Input, EventEmitter, ViewChild } from '@angular/core';
import { IpersonaComponent } from './ipersona/ipersona.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Aplicación Acorde';

  constructor() {
   }
}


