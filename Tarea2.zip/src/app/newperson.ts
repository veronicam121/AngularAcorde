import { Ipersona } from './ipersona';

export abstract class NewPerson {
    abstract newPerson(persona: Ipersona): void;
}
